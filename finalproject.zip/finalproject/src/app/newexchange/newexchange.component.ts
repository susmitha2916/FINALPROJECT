import { Component, OnInit } from '@angular/core';
import { exchange } from 'src/entity/exchange';
import { ExchangeService } from '../service/exchange.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-newexchange',
  templateUrl: './newexchange.component.html',
  styleUrls: ['./newexchange.component.css']
})
export class NewexchangeComponent implements OnInit {
  exchange :exchange[];
  myForm4:FormGroup

  constructor(private service:ExchangeService,private router:Router) { }

  ngOnInit() :void {
    this.service. getAll().subscribe(data =>{
      this.exchange=data.body;
      
      });
      {
        this.myForm4=new FormGroup({
          id:new FormControl(''),
          exchange:new FormControl(''),
          brief:new FormControl(''),
          contactaddress:new FormControl(''),
          remark:new FormControl(''),
          
        });
      }
        
      
    }
      onSubmit(myForm4: FormGroup)
    {
      let  exchange:exchange={
        id:myForm4.value.id,
       
        stock_exchange:myForm4.value.exchange,
        brief:myForm4.value. brief,
        contact_address:myForm4.value.contactaddress,
        remarks:myForm4.value. remark,
        
      }
      this.service. save(exchange).subscribe(data =>{
        console.log(data.body);
          });
          this.router.navigate(['/']);
          
    } 
    
}


