import { TestBed } from '@angular/core/testing';

import { SummerService } from './summer.service';

describe('SummerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SummerService = TestBed.get(SummerService);
    expect(service).toBeTruthy();
  });
});
