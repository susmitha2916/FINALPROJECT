import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewipoComponent } from './newipo.component';

describe('NewipoComponent', () => {
  let component: NewipoComponent;
  let fixture: ComponentFixture<NewipoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewipoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewipoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
