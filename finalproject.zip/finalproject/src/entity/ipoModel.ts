export interface IpoModel{
    Id?:number;
    company_name :string;
    stock_id:number;
    price_per_share:number;
    no_of_shares:number;
    remarks :string;
  
}