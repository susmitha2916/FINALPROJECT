import { TestBed } from '@angular/core/testing';

import { IpoService } from './ipo.service';

describe('IpoService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: IpoService = TestBed.get(IpoService);
    expect(service).toBeTruthy();
  });

  //describe('getAllIpo',()=>{
    
    //   it('successfull',()=>{
    //     let result = service.getAllIpo();
    //     expect(result).toBe(20);
    //   });
     
    //   it('succsessfull',()=>{
    //     expect(service.getAllIpo()).toBe();
    //   });
  
    //   it('should returnvalue when we get iPO ',()=>{
    //     expect(service.getAllIpo()).toBe();
    //     expect(service.getAllIpo()).toBe();
    //   });
    // }); 






});
