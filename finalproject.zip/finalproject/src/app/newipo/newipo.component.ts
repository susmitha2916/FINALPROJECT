import { Component, OnInit } from '@angular/core';
import { IpoModel } from 'src/entity/IpoModel';
import { IpoService } from '../service/ipo.service';

@Component({
  selector: 'app-newipo',
  templateUrl: './newipo.component.html',
  styleUrls: ['./newipo.component.css']
})
export class NewipoComponent implements OnInit {
ipo :IpoModel[];
  constructor(private service:IpoService) { }

  ngOnInit():void {
    this.service.getAllIpo().subscribe(data =>{
      this.ipo=data.body;
      
      });

}
}
