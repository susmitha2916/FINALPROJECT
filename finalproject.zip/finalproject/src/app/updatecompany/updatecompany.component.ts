import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatecompany',
  templateUrl: './updatecompany.component.html',
  styleUrls: ['./updatecompany.component.css']
})
export class UpdatecompanyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
