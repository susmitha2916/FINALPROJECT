import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { SummerService } from '../service/summer.service';
@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent implements OnInit {

 
  excel:any
  constructor(private router:Router,private service:SummerService) { }

 
  ngOnInit(): void {
    this.service.summary1().subscribe(data => {
         this.excel = data.body;
         console.log(data.body);
    });
  }
  ons(){
    this.router.navigate(['/']);
  }
  

}