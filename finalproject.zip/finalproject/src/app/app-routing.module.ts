import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AdminlandingComponent } from './adminlanding/adminlanding.component';
import { ImportdataComponent } from './importdata/importdata.component';
import { ManagecompanyComponent } from './managecompany/managecompany.component';
import { ManageexchangeComponent } from './manageexchange/manageexchange.component';
import { CreatecompanyComponent } from './createcompany/createcompany.component';
import { UserlandingComponent } from './userlanding/userlanding.component';
import { UpdatecompanyComponent } from './updatecompany/updatecompany.component';
import { IpoComponent } from './ipo/ipo.component';
import { combineLatest } from 'rxjs';
import { CompareSectorComponent } from './compare-sector/compare-sector.component';
import { OtherComponent } from './other/other.component';
import { MyBarChartComponent } from './my-bar-chart/my-bar-chart.component';
import { HomeComponent } from './home/home.component';
import { NewipoComponent } from './newipo/newipo.component';
import { NewexchangeComponent } from './newexchange/newexchange.component';
import { MyPieChartComponent } from './my-pie-chart/my-pie-chart.component';
import { SummaryComponent } from './summary/summary.component';

const routes: Routes = [
  {path:'',redirectTo:'/home',pathMatch:'full'},
  {path:'home',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'adminlanding',component:AdminlandingComponent},
  {path:'importdata',component:ImportdataComponent},
  {path:'managecompany',component:ManagecompanyComponent},
  {path:'manageexchange',component:ManageexchangeComponent},
  {path:'createcompany',component:CreatecompanyComponent},
  {path:'userlanding',component:UserlandingComponent},
  {path:'update',component:UpdatecompanyComponent},
  {path:'ipo',component:IpoComponent},
  {path:'compare-sector',component:CompareSectorComponent},
  {path:'other',component:OtherComponent},
  {path:'my-bar-chart',component:MyBarChartComponent},
  {path:'ipos',component:NewipoComponent},
  {path:'newexchange',component:NewexchangeComponent},
  {path:'my-pie-chart',component:MyPieChartComponent},
  {path:'summary',component:SummaryComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
